/* MultiPU Hub Worker
   Cloudflare Workers + KV. No secrets belong in index.html.
   Bindings: SITES (KV), SITE_CONFIG (KV), TELEMETRY (KV, optional).
*/

const JSON_HEADERS = {'content-type':'application/json; charset=utf-8'};

function cors(env){
  const allowed=(env.ALLOWED_ORIGIN||'*').trim();
  return {'access-control-allow-origin':allowed,'access-control-allow-methods':'GET,POST,PUT,DELETE,OPTIONS','access-control-allow-headers':'content-type,authorization','access-control-max-age':'86400'};
}
function out(data,status=200,env){return new Response(JSON.stringify(data),{status,headers:{...JSON_HEADERS,...cors(env)}})}
function now(){return new Date().toISOString()}
function id(){return crypto.randomUUID()}

async function bearer(request){
  const h=request.headers.get('authorization')||'';
  return h.startsWith('Bearer ')?h.slice(7).trim():'';
}
async function googleIdentity(token){
  if(!token) return null;
  try{
    const r=await fetch('https://oauth2.googleapis.com/tokeninfo?id_token='+encodeURIComponent(token));
    if(!r.ok)return null;
    const d=await r.json();
    if(d.email_verified!=='true' && d.email_verified!==true)return null;
    return {email:String(d.email||'').toLowerCase(),name:d.name||'',sub:d.sub||''};
  }catch(e){return null}
}
async function requireAdmin(request,env){
  const ident=await googleIdentity(await bearer(request));
  if(!ident)return null;
  const admins=(env.ADMIN_EMAILS||'mdmasterdan@gmail.com,multipuhub@gmail.com').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
  return admins.includes(ident.email)?ident:null;
}
function cleanSite(x){
  return {
    id:String(x.id||id()).slice(0,80),
    n:String(x.n||'Partner site').slice(0,80),
    u:String(x.u||'').slice(0,500),
    type:x.type==='offspring'?'offspring':'partner',
    desc:String(x.desc||'Partner storefront').slice(0,220),
    cta:String(x.cta||'OPEN SITE').slice(0,34),
    parentId:String(x.parentId||'').slice(0,80),
    packageName:String(x.packageName||'').slice(0,80),
    preview:String(x.preview||x.u||'').slice(0,500),
    updatedAt:now()
  };
}
async function readSites(env){
  const raw=env.SITES?await env.SITES.get('sites'):null;
  if(!raw)return [];
  try{return JSON.parse(raw)}catch(e){return []}
}
async function writeSites(env,sites){if(env.SITES)await env.SITES.put('sites',JSON.stringify(sites.slice(0,500)))}
async function aiChat(messages,env){
  const base=(env.AI_BASE_URL||'').replace(/\/$/,'');
  const model=env.AI_MODEL||'qwen2.5:7b';
  if(!base)return null;
  const r=await fetch(base+'/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({model,messages,stream:false,options:{temperature:0.4}})});
  if(!r.ok)throw new Error('AI backend '+r.status);
  const d=await r.json();
  return d.message?.content||d.response||'';
}

export default {
  async fetch(request,env){
    const url=new URL(request.url),path=url.pathname.replace(/\/+$/,'')||'/';
    if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors(env)});
    try{
      if(path==='/health'&&request.method==='GET')return out({status:'healthy',service:'multipu-hub-worker',time:now(),sites:!!env.SITES,ai:!!env.AI_BASE_URL},200,env);
      if(path==='/ai/health'&&request.method==='GET')return out({status:env.AI_BASE_URL?'configured':'fallback',provider:env.AI_BASE_URL?'ollama-compatible':'local-fallback',model:env.AI_MODEL||'qwen2.5:7b',voice:{stt:!!env.AI_STT_URL,tts:!!env.AI_TTS_URL,avatar:!!env.AI_AVATAR_URL}},200,env);

      if(path==='/sites'&&request.method==='GET'){
        const sites=await readSites(env);
        return out({sites},200,env);
      }
      if(path==='/sites'&&request.method==='POST'){
        const admin=await requireAdmin(request,env);if(!admin)return out({error:'Admin authorization required'},401,env);
        const body=await request.json();const site=cleanSite(body);
        if(!/^https?:\/\//i.test(site.u))return out({error:'A valid http(s) site URL is required'},400,env);
        if(site.type==='offspring'&&!site.parentId)return out({error:'Offspring sites require parentId'},400,env);
        const sites=await readSites(env);const next=[site,...sites.filter(x=>x.u!==site.u&&x.id!==site.id)];await writeSites(env,next);
        return out({ok:true,site},201,env);
      }
      const sm=path.match(/^\/sites\/([^/]+)$/);
      if(sm&&request.method==='DELETE'){
        const admin=await requireAdmin(request,env);if(!admin)return out({error:'Admin authorization required'},401,env);
        const sites=await readSites(env),next=sites.filter(x=>x.id!==decodeURIComponent(sm[1]));await writeSites(env,next);return out({ok:true},200,env);
      }

      if(path==='/site'&&request.method==='GET'){
        const raw=env.SITE_CONFIG?await env.SITE_CONFIG.get('site'):null;let d={ov:{},ovi:{},banner:''};if(raw)try{d=JSON.parse(raw)}catch(e){}return out(d,200,env);
      }
      if(path==='/site'&&request.method==='PUT'){
        const admin=await requireAdmin(request,env);if(!admin)return out({error:'Admin authorization required'},401,env);
        const body=await request.json();const d={ov:body.ov||{},ovi:body.ovi||{},banner:String(body.banner||'').slice(0,500),updatedAt:now(),updatedBy:admin.email};
        if(env.SITE_CONFIG)await env.SITE_CONFIG.put('site',JSON.stringify(d));return out({ok:true,site:d},200,env);
      }

      if((path==='/chat'||path==='/ai/chat')&&request.method==='POST'){
        const body=await request.json();const messages=Array.isArray(body.messages)?body.messages.slice(-20):[];
        let reply='I\'m AURA, the MultiPU Hub assistant. I can help you explore services, Partner sites, Offspring sites, proposals, support and bookings.';
        try{const ai=await aiChat([{role:'system',content:'You are AURA for MultiPU Hub. Be concise, helpful, and transparent. Never claim an action happened unless the system confirms it.'},...messages],env);if(ai)reply=ai}catch(e){reply+=' The local AI service is currently unavailable, so I am using the safe fallback.'}
        return out({reply,provider:env.AI_BASE_URL?'self-hosted':'fallback',time:now()},200,env);
      }

      if(path==='/telemetry'&&request.method==='POST'){
        const body=await request.json();
        const safe={event:String(body.event||'event').slice(0,80),site:String(body.site||'hub').slice(0,80),state:String(body.state||'').slice(0,30),ts:now()};
        if(env.TELEMETRY){const key='evt:'+Date.now()+':'+Math.random().toString(36).slice(2);await env.TELEMETRY.put(key,JSON.stringify(safe),{expirationTtl:60*60*24*30});}
        return out({ok:true},202,env);
      }
      return out({error:'Not found'},404,env);
    }catch(e){return out({error:'Server error',detail:env.DEBUG==='true'?String(e.message||e):undefined},500,env)}
  }
};
